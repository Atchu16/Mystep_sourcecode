[
{ "name": " Step A ","desc": "&rarr; Step B"  ,"values": [{"id": "b0", "from": "/Date(1320182000000)/", "to": "/Date(1320301600000)/", "desc": "Id: 0<br/>Name:   Step A", "label": " Step A", "customClass": "ganttRed", "dep": "b1"}]},
{ "name": " Step B ","desc": "&rarr; step C"  ,"values": [{"id": "b1", "from": "/Date(1320601600000)/", "to": "/Date(1320870400000)/", "desc": "Id: 1<br/>Name:   Step B", "label": " Step B", "customClass": "ganttOrange", "dep": "b2"}]},
{ "name": " Step C ","desc": "&rarr; step D"  ,"values": [{"id": "b2", "from": "/Date(1321192000000)/", "to": "/Date(1321500400000)/", "desc": "Id: 2<br/>Name:   Step C", "label": " Step C", "customClass": "ganttGreen", "dep": "b3"}]},
{ "name": " Step D ","desc": "&rarr; step E"  ,"values": [{"id": "b3", "from": "/Date(1320302400000)/", "to": "/Date(1320551600000)/", "desc": "Id: 3<br/>Name:   Step D", "label": " Step D", "dep": "b4"}]},
{ "name": " Step E ","desc": "&mdash;"        ,"values": [{"id": "b4", "from": "/Date(1320802400000)/", "to": "/Date(1321994800000)/", "desc": "Id: 4<br/>Name:   Step E", "label": " Step E", "customClass": "ganttRed"}]},
{ "name": " Step F ","desc": "&rarr; step B"  ,"values": [{"id": "b5", "from": "/Date(1320192000000)/", "to": "/Date(1320401600000)/", "desc": "Id: 5<br/>Name:   Step F", "label": " Step F", "customClass": "ganttOrange", "dep": "b1"}]},
{ "name": " Step G ","desc": "&rarr; step C"  ,"values": [{"id": "b6", "from": "/Date(1320401600000)/", "to": "/Date(1320570400000)/", "desc": "Id: 6<br/>Name:   Step G", "label": " Step G", "customClass": "ganttGreen", "dep": "b8"}]},
{ "name": " Step H ","desc": "&rarr; Step J"  ,"values": [{"id": "b7", "from": "/Date(1321192000000)/", "to": "/Date(1321500400000)/", "desc": "Id: 7<br/>Name:   Step H", "label": " Step H", "dep": "b9"}]},
{ "name": " Step I ","desc": "&rarr; Step H"  ,"values": [{"id": "b8", "from": "/Date(1320302400000)/", "to": "/Date(1320551600000)/", "desc": "Id: 8<br/>Name:   Step I", "label": " Step I", "customClass": "ganttRed", "dep": "b7"}]},
{ "name": " Step J ","desc": "&mdash;"        ,"values": [{"id": "b9", "from": "/Date(1320802400000)/", "to": "/Date(1321994800000)/", "desc": "Id: 9<br/>Name:   Step J", "label": " Step J", "customClass": "ganttOrange"}]}
]
