package com.kirak.util.exception;

/**
 * Created by Kir on 14.06.2017.
 */
public class NotFoundException extends RuntimeException {
    public NotFoundException(String message) {
        super(message);
    }
}
