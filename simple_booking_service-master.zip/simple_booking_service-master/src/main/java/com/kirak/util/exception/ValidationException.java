package com.kirak.util.exception;

/**
 * Created by Kir on 17.06.2017.
 */
public class ValidationException extends RuntimeException{
    public ValidationException(String message){
        super(message);
    }
}
