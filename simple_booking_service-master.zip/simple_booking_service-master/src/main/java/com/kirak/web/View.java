package com.kirak.web;

/**
 * Created by Kir on 18.06.2017.
 */
public class View {

    public interface JsonUI {}

    public interface ValidatedUIGroup {}

    //Fot Tests
    public interface JsonREST {}
}
